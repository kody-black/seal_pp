### Update:

1. seal-decl.cc第23行，更新为

```c
return new Variable_class(copy_Symbol(type), copy_Symbol(name));
```

